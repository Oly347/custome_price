-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2019 at 09:52 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tilottama_tech`
--

-- --------------------------------------------------------

--
-- Table structure for table `component_details`
--

CREATE TABLE `component_details` (
  `id` int(100) NOT NULL,
  `component_name` varchar(100) NOT NULL,
  `component_details` varchar(100) NOT NULL,
  `component_price` double(10,2) NOT NULL,
  `component_image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `component_details`
--

INSERT INTO `component_details` (`id`, `component_name`, `component_details`, `component_price`, `component_image`) VALUES
(17, 'hasan', 'hahaha', 0.00, '1550639044matt-seymour-1138384-unsplash.jpg'),
(18, 'hasan', 'developer', 0.14, '1550646675c83ae5cf-ea44-4152-8593-f1b7577328041544698158128-Calvin-Klein-Jeans-Men-White-Printed-Round-Neck-T-shirt-8041-1.jpg'),
(19, 'Ram', 'DDR4X', 4000.00, '1550647214cassette-1941723_1920.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `component_master`
--

CREATE TABLE `component_master` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `component_master`
--

INSERT INTO `component_master` (`id`, `name`) VALUES
(1, 'CPU'),
(2, 'MOTHERBOARD');

-- --------------------------------------------------------

--
-- Table structure for table `login_id`
--

CREATE TABLE `login_id` (
  `id` int(100) NOT NULL,
  `login_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_id`
--

INSERT INTO `login_id` (`id`, `login_time`) VALUES
(1, '2019-02-20 00:00:00'),
(2, '2019-02-20 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `price_list`
--

CREATE TABLE `price_list` (
  `id` int(100) NOT NULL,
  `CPU` varchar(100) NOT NULL,
  `CAB` varchar(100) NOT NULL,
  `SMPS` varchar(100) NOT NULL,
  `RAM` varchar(100) NOT NULL,
  `Total` int(11) NOT NULL,
  `temp_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `price_list`
--

INSERT INTO `price_list` (`id`, `CPU`, `CAB`, `SMPS`, `RAM`, `Total`, `temp_id`) VALUES
(13, '1', '5', '10', '15', 31, 0),
(14, '2', '5', '10', '14', 31, 0),
(15, '2', '5', '10', '13', 30, 0),
(16, '1', '5', '9', '15', 30, 0),
(17, '4', '8', '11', '15', 38, 0),
(18, '1', '8', '12', '14', 35, 0),
(19, '1', '6', '10', '16', 33, 0),
(20, '1', '5', '9', '16', 31, 0),
(21, '1', '5', '9', '16', 31, 0),
(22, '1', '7', '10', '16', 34, 0),
(23, '1', '5', '9', '16', 31, 0),
(24, '2', '5', '9', '16', 32, 0),
(25, '1', '5', '9', '16', 31, 0),
(26, '1', '5', '9', '15', 30, 0),
(27, '1', '5', '10', '16', 32, 104),
(28, '1', '6', '9', '16', 32, 904),
(29, '1', '5', '9', '16', 31, 506),
(30, '1', '6', '9', '15', 31, 746),
(31, '1', '5', '10', '16', 32, 732),
(32, '1', '6', '9', '16', 32, 550),
(33, '1', '5', '9', '14', 29, 846),
(34, '1', '5', '9', '15', 30, 0),
(40, '1', '5', '9', '16', 31, 1),
(42, '2', '5', '10', '14', 31, 2),
(43, '1', '5', '10', '16', 32, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `component_details`
--
ALTER TABLE `component_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `component_master`
--
ALTER TABLE `component_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_id`
--
ALTER TABLE `login_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `price_list`
--
ALTER TABLE `price_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_id` (`email_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `component_details`
--
ALTER TABLE `component_details`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `component_master`
--
ALTER TABLE `component_master`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `login_id`
--
ALTER TABLE `login_id`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `price_list`
--
ALTER TABLE `price_list`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
